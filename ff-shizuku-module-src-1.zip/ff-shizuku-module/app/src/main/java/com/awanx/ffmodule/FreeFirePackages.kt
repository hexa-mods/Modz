package com.awanx.ffmodule

object FreeFirePackages {
    const val FF_TH = "com.dts.freefireth"
    const val FF_MAX = "com.dts.freefiremax"
    const val FF_VN = "com.garena.game.kgvn"
    const val FF_SAR = "com.garena.game.kgsar"

    data class Entry(
        val packageName: String,
        val displayName: String,
        val radioId: Int
    )

    val known = listOf(
        Entry(FF_TH, "Free Fire (TH/Global)", R.id.rbFFTH),
        Entry(FF_MAX, "Free Fire MAX", R.id.rbFFMax),
        Entry(FF_VN, "Free Fire VN", R.id.rbFFVN),
    )
}
