package com.awanx.ffmodule

import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.awanx.ffmodule.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var shizukuReady = false

    /** Path to your injector / module binary on device. Change if needed. */
    private val defaultModulePath = "/data/local/tmp/ff_module"

    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            shizukuReady = grantResult == PackageManager.PERMISSION_GRANTED
            updateShizukuUi()
            if (shizukuReady) {
                log("[+] Shizuku permission granted")
                refreshPackageStatus()
            } else {
                log("[!] Shizuku permission denied")
            }
        }

    private val shizukuBinderListener = object : Shizuku.OnBinderReceivedListener {
        override fun onBinderReceived() {
            runOnUiThread {
                log("[*] Shizuku binder connected")
                checkShizuku()
            }
        }
    }

    private val shizukuBinderDeadListener = object : Shizuku.OnBinderDeadListener {
        override fun onBinderDead() {
            runOnUiThread {
                shizukuReady = false
                log("[!] Shizuku binder dead")
                updateShizukuUi()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupShizuku()
        setupUi()
        checkShizuku()
    }

    private fun setupShizuku() {
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.addBinderReceivedListener(shizukuBinderListener)
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener)
    }

    private fun setupUi() {
        binding.btnRequestShizuku.setOnClickListener { requestShizukuPermission() }
        binding.btnRun.setOnClickListener { runModule() }
        binding.btnStop.setOnClickListener { stopTarget() }
        binding.btnClearLog.setOnClickListener {
            binding.tvLog.text = "Log cleared.\n"
        }

        binding.rgFreeFire.setOnCheckedChangeListener { _, checkedId ->
            binding.tilCustomPackage.visibility =
                if (checkedId == R.id.rbCustom) View.VISIBLE else View.GONE
            refreshPackageStatus()
        }

        // Default select first known FF
        binding.rbFFTH.isChecked = true
    }

    private fun checkShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                shizukuReady = false
                updateShizukuUi()
                log("[!] Shizuku service not running — buka app Shizuku dulu")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuReady = true
                log("[+] Shizuku ready")
            } else {
                shizukuReady = false
                log("[*] Shizuku running, but permission belum diberikan")
            }
        } catch (e: Exception) {
            shizukuReady = false
            log("[!] Shizuku error: ${e.message}")
        }
        updateShizukuUi()
        if (shizukuReady) refreshPackageStatus()
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Buka app Shizuku dan start service dulu")
                log("[!] Shizuku not running")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuReady = true
                updateShizukuUi()
                toast("Sudah punya izin Shizuku")
                return
            }
            Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
            log("[*] Requesting Shizuku permission…")
        } catch (e: Exception) {
            log("[!] Request failed: ${e.message}")
            toast("Gagal minta izin: ${e.message}")
        }
    }

    private fun updateShizukuUi() {
        if (shizukuReady) {
            binding.tvShizukuStatus.text = "Shizuku OK"
            binding.tvShizukuStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
            binding.tvShizukuDetail.text = "Service aktif · Permission granted · Siap menjalankan command"
            binding.btnRequestShizuku.isEnabled = false
            binding.btnRequestShizuku.text = "Shizuku Siap ✓"
            binding.btnRun.isEnabled = true
        } else {
            binding.tvShizukuStatus.text = "Shizuku ?"
            binding.tvShizukuStatus.setTextColor(ContextCompat.getColor(this, R.color.warning))
            val running = try { Shizuku.pingBinder() } catch (_: Exception) { false }
            binding.tvShizukuDetail.text = if (running) {
                "Service aktif, tapi permission belum diberikan. Tekan tombol di bawah."
            } else {
                "Shizuku tidak aktif. Install & buka app Shizuku, start via Wireless debugging / Root."
            }
            binding.btnRequestShizuku.isEnabled = true
            binding.btnRequestShizuku.text = "Minta Izin Shizuku"
            binding.btnRun.isEnabled = false
        }
    }

    private fun selectedPackage(): String? {
        return when (binding.rgFreeFire.checkedRadioButtonId) {
            R.id.rbFFTH -> FreeFirePackages.FF_TH
            R.id.rbFFMax -> FreeFirePackages.FF_MAX
            R.id.rbFFVN -> FreeFirePackages.FF_VN
            R.id.rbCustom -> {
                val custom = binding.etCustomPackage.text?.toString()?.trim().orEmpty()
                custom.ifBlank { null }
            }
            else -> null
        }
    }

    private fun refreshPackageStatus() {
        val pkg = selectedPackage() ?: run {
            binding.tvPackageStatus.text = "Pilih package dulu"
            binding.tvPackageStatus.setTextColor(ContextCompat.getColor(this, R.color.text_dim))
            return
        }
        if (!shizukuReady) {
            // Fallback: PackageManager (no shell)
            val installed = try {
                packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
            binding.tvPackageStatus.text = if (installed) "✓ Terinstall (PM)" else "✗ Tidak terinstall"
            binding.tvPackageStatus.setTextColor(
                ContextCompat.getColor(this, if (installed) R.color.success else R.color.danger)
            )
            return
        }
        lifecycleScope.launch {
            val installed = withContext(Dispatchers.IO) { ShizukuShell.isInstalled(pkg) }
            binding.tvPackageStatus.text = if (installed) "✓ Terinstall · $pkg" else "✗ Tidak terinstall · $pkg"
            binding.tvPackageStatus.setTextColor(
                ContextCompat.getColor(this@MainActivity, if (installed) R.color.success else R.color.danger)
            )
        }
    }

    private fun runModule() {
        if (!shizukuReady) {
            toast("Shizuku belum siap")
            return
        }
        val pkg = selectedPackage()
        if (pkg.isNullOrBlank()) {
            toast("Pilih Free Fire dulu")
            return
        }

        val clearCache = binding.cbClearCache.isChecked
        val forceStop = binding.cbForceStop.isChecked
        val launch = binding.cbLaunchGame.isChecked

        binding.btnRun.isEnabled = false
        binding.btnRun.text = "Running…"

        lifecycleScope.launch {
            log("──────────────")
            log("[*] Start pipeline")
            val ok = withContext(Dispatchers.IO) {
                ShizukuShell.runPipeline(
                    packageName = pkg,
                    modulePath = defaultModulePath,
                    clearCache = clearCache,
                    forceStopFirst = forceStop,
                    launchGame = launch,
                    log = { msg -> runOnUiThread { log(msg) } }
                )
            }
            log(if (ok) "[+] Pipeline selesai" else "[!] Pipeline gagal / partial")
            log("──────────────")
            binding.btnRun.isEnabled = true
            binding.btnRun.text = "⚡ JALANKAN MODULE"
            toast(if (ok) "Selesai" else "Ada error — cek log")
        }
    }

    private fun stopTarget() {
        if (!shizukuReady) {
            toast("Shizuku belum siap")
            return
        }
        val pkg = selectedPackage()
        if (pkg.isNullOrBlank()) {
            toast("Pilih package dulu")
            return
        }
        lifecycleScope.launch {
            log("[*] Force-stop $pkg")
            val r = withContext(Dispatchers.IO) { ShizukuShell.forceStop(pkg) }
            log(if (r.exitCode == 0) "[+] Stopped" else "[!] ${r.stderr.ifBlank { r.stdout }}")
        }
    }

    private fun log(msg: String) {
        binding.tvLog.append(msg + "\n")
        // auto-scroll: parent ScrollView
        binding.tvLog.post {
            val parent = binding.tvLog.parent
            if (parent is android.widget.ScrollView) {
                parent.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.removeBinderReceivedListener(shizukuBinderListener)
        Shizuku.removeBinderDeadListener(shizukuBinderDeadListener)
    }

    companion object {
        private const val REQUEST_CODE_SHIZUKU = 1001
    }
}
