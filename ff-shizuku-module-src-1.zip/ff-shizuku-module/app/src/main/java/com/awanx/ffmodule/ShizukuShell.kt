package com.awanx.ffmodule

import android.os.ParcelFileDescriptor
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Run shell commands through Shizuku (adb/shell privilege without root).
 * Requires Shizuku app running + permission granted to this package.
 */
object ShizukuShell {

    data class Result(
        val exitCode: Int,
        val stdout: String,
        val stderr: String
    )

    fun isReady(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun isRunning(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Execute a shell command via Shizuku's newProcess.
     * Returns stdout+stderr and exit code.
     */
    fun exec(command: String, timeoutSec: Long = 30): Result {
        if (!isReady()) {
            return Result(-1, "", "Shizuku not ready (not running or no permission)")
        }

        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                ?: return Result(-1, "", "Shizuku.newProcess returned null")

            val stdout = StringBuilder()
            val stderr = StringBuilder()

            val outThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            stdout.appendLine(line)
                        }
                    }
                } catch (_: Exception) {}
            }
            val errThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            stderr.appendLine(line)
                        }
                    }
                } catch (_: Exception) {}
            }

            outThread.start()
            errThread.start()

            val finished = process.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!finished) {
                process.destroy()
                return Result(-1, stdout.toString(), "Timeout after ${timeoutSec}s")
            }

            outThread.join(2000)
            errThread.join(2000)

            Result(process.exitValue(), stdout.toString().trim(), stderr.toString().trim())
        } catch (e: Exception) {
            Result(-1, "", "Exception: ${e.message}")
        }
    }

    /** Force-stop a package */
    fun forceStop(packageName: String): Result {
        return exec("am force-stop $packageName")
    }

    /** Clear app cache (not data) */
    fun clearCache(packageName: String): Result {
        return exec("pm clear --cache-only $packageName 2>/dev/null || rm -rf /data/data/$packageName/cache/* 2>/dev/null; echo done")
    }

    /** Launch main activity of package */
    fun launch(packageName: String): Result {
        return exec("monkey -p $packageName -c android.intent.category.LAUNCHER 1")
    }

    /** Check if package installed */
    fun isInstalled(packageName: String): Boolean {
        val r = exec("pm path $packageName")
        return r.exitCode == 0 && r.stdout.contains("package:")
    }

    /** Get PID of running process for package (0 if not running) */
    fun getPid(packageName: String): Int {
        val r = exec("pidof $packageName")
        if (r.exitCode != 0 || r.stdout.isBlank()) return 0
        return r.stdout.trim().split("\\s+".toRegex()).firstOrNull()?.toIntOrNull() ?: 0
    }

    /**
     * Inject / run a native module into target process using simple LD approach
     * or shell-based attachment. This is the hook point for your .so module.
     *
     * For a real injector you would:
     *  1. Copy your libmodule.so to a readable path
     *  2. Use ptrace / android_dlopen_ext via a helper binary run as shell
     *
     * Here we provide the shell scaffolding + placeholder inject command
     * that you replace with your actual injector binary path.
     */
    fun runModule(
        packageName: String,
        modulePath: String,
        extraArgs: String = ""
    ): Result {
        // Example: run a userspace injector that takes package + .so path
        // Replace /data/local/tmp/injector with your real binary when you ship one.
        val cmd = buildString {
            append("if [ -f \"$modulePath\" ]; then ")
            append("  chmod 755 \"$modulePath\" 2>/dev/null; ")
            // If modulePath is an executable runner:
            append("  \"$modulePath\" \"$packageName\" $extraArgs; ")
            append("else ")
            append("  echo \"MODULE_NOT_FOUND:$modulePath\"; exit 2; ")
            append("fi")
        }
        return exec(cmd, timeoutSec = 60)
    }

    /** Full pipeline: optional clear → force-stop → launch → inject */
    fun runPipeline(
        packageName: String,
        modulePath: String?,
        clearCache: Boolean,
        forceStopFirst: Boolean,
        launchGame: Boolean,
        log: (String) -> Unit
    ): Boolean {
        log("[*] Target: $packageName")

        if (!isInstalled(packageName)) {
            log("[!] Package not installed")
            return false
        }
        log("[+] Package installed")

        if (clearCache) {
            log("[*] Clearing cache…")
            val r = clearCache(packageName)
            log(if (r.exitCode == 0) "[+] Cache cleared" else "[!] Clear cache: ${r.stderr.ifBlank { r.stdout }}")
        }

        if (forceStopFirst) {
            log("[*] Force-stop…")
            val r = forceStop(packageName)
            log(if (r.exitCode == 0) "[+] Stopped" else "[!] Force-stop: ${r.stderr.ifBlank { r.stdout }}")
            Thread.sleep(800)
        }

        if (launchGame) {
            log("[*] Launching…")
            val r = launch(packageName)
            log(if (r.exitCode == 0) "[+] Launched" else "[!] Launch: ${r.stderr.ifBlank { r.stdout }}")
            Thread.sleep(2500)
        }

        val pid = getPid(packageName)
        if (pid > 0) {
            log("[+] PID: $pid")
        } else {
            log("[!] Process not found after launch (may still be starting)")
        }

        if (!modulePath.isNullOrBlank()) {
            log("[*] Running module: $modulePath")
            val r = runModule(packageName, modulePath)
            log("[*] Module exit=${r.exitCode}")
            if (r.stdout.isNotBlank()) log(r.stdout)
            if (r.stderr.isNotBlank()) log(r.stderr)
            return r.exitCode == 0
        } else {
            log("[*] No module path set — launch/stop only")
            return true
        }
    }
}
