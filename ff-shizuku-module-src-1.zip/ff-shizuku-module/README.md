# AWAN X — Free Fire Run Module (Shizuku)

APK module runner untuk Free Fire via **Shizuku** (tanpa root).  
Bisa pilih package Free Fire: TH/Global, MAX, VN, atau custom.

## Fitur

- Deteksi status Shizuku (running / permission)
- Pilih Free Fire:
  - `com.dts.freefireth` — Free Fire TH / Global
  - `com.dts.freefiremax` — Free Fire MAX
  - `com.garena.game.kgvn` — Free Fire VN
  - Custom package name
- Opsi: force-stop, clear cache, auto-launch
- Pipeline: stop → (optional clear) → launch → run module
- Log realtime di UI
- Shell command via `Shizuku.newProcess` (privilege adb/shell)

## Requirement HP

1. **Shizuku** terinstall & service aktif  
   - Android 11+: Wireless debugging  
   - Atau root  
2. Beri permission Shizuku ke app ini (tombol di UI)
3. Free Fire terinstall
4. (Opsional) Binary module/injector di `/data/local/tmp/ff_module`

## Build

```bash
# di folder project
./gradlew assembleDebug
# output: app/build/outputs/apk/debug/app-debug.apk
```

Atau buka di **Android Studio** → Sync → Run.

## Module path

Default injector path di kode:

```
/data/local/tmp/ff_module
```

Ganti di `MainActivity.kt` → `defaultModulePath` sesuai binary kamu.  
Binary harus executable (`chmod 755`) dan dijalankan dengan argumen package name.

## Alur pakai

1. Install APK ini
2. Buka **Shizuku** → Start
3. Buka **AWAN X FF Module**
4. Tekan **Minta Izin Shizuku** → Allow
5. Pilih Free Fire yang terinstall
6. Centang opsi (force-stop / launch / clear cache)
7. Tekan **JALANKAN MODULE**
8. Lihat log

## Catatan teknis

- `ShizukuShell.exec()` menjalankan `sh -c <cmd>` lewat process Shizuku
- `force-stop` / `monkey` / `pm path` / `pidof` semua lewat shell privilege
- Injector asli (ptrace / android_dlopen_ext) diganti path binary kamu di `runModule()`
- Tidak butuh root; cukup Shizuku shell UID

## Package ID

`com.awanx.ffmodule`

## Versi

1.0.0
